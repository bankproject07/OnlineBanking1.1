package com.cg.obs.util;

import java.sql.Connection;
import java.sql.SQLException;



import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil 
{
	public static Connection getConnection() throws SQLException {

		/*
		 * OracleDataSource ods= new OracleDataSource();
		 * ods.setUser("Labg103trg28"); ods.setPassword("labg103oracle");
		 * ods.setDriverType("thin"); ods.setNetworkProtocol("tcp");
		 * ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
		 */
		InitialContext ic;
		DataSource ds;
		Connection con = null;
		try {
			ic = new InitialContext();
			ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		} catch (NamingException e) {

			e.printStackTrace();
		}

		return con;
	}
}
