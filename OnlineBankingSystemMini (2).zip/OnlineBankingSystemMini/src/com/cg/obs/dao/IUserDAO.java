package com.cg.obs.dao;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public interface IUserDAO
{
	public Users getUser(int id) throws UserException;
	public Admin getAdmin(int id) throws UserException;
}
